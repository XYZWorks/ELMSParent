package test.java.transport;

import vo.strategy.ConstVO;
 /** 
 * 
 * @author czq 
 * @version 2015年11月15日 上午10:48:59 
 */
public class MockStrategy {

	public ConstVO getConst() {
		return null;
//		return new ConstVO(mileInBN, mileInBS, mileInBG, mileInNS, mileInNG, mileINSG, plane, train, truck, paperBox, woodBox, plasticBag, ratios);
	}


	
	
	
}
