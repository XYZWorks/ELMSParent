package test.java.order;

import test.java.other.DataTool;
import vo.strategy.ConstVO;
 /** 
 * 
 * @author czq 
 * @version 2015年11月15日 上午11:14:34 
 */
public class MockStrategy {

	public ConstVO getConst() {
		return DataTool.getConst();
	}


	
	

}
