package test.java.personnel;

import bl.personnelbl.Personnel;

/** 
 * @author ymc 
 * @version 创建时间：2015年11月10日 上午9:40:30 
 *
 */
public class MockPersonnelblImpl extends Personnel {

}
