package test.java.finace;

import bl.financebl.Pay;

/** 
 * @author ymc 
 * @version 创建时间：2015年11月10日 上午9:39:17 
 *
 */
public class MockPayImpl extends Pay {

}
