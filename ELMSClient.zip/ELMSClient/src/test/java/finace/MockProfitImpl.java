package test.java.finace;

import bl.financebl.Profit;

/** 
 * @author ymc 
 * @version 创建时间：2015年11月10日 上午9:39:37 
 *
 */
public class MockProfitImpl extends Profit {

}
