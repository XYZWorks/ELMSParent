package test.java.finace;

import bl.financebl.Deposit;

/** 
 * @author ymc 
 * @version 创建时间：2015年11月10日 上午9:38:59 
 *
 */
public class MockDepositImpl extends Deposit {

}
