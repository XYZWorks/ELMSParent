package bl.financebl;

import java.util.ArrayList;

import blservice.financeblservice.PayService;
import ds.financedataservice.FinanceDataService;
import util.ResultMessage;
import vo.finance.PayVO;

/** 
 * @author ymc 
 * @version 创建时间：2015年10月27日 下午7:47:03 
 *
 */
public class Pay {
	FinanceDataService financebl;
	public ResultMessage create(PayVO vo) {
		// TODO Auto-generated method stub
		return null;
	}

	public ArrayList<PayVO> showPays() {
		// TODO Auto-generated method stub
		return null;
	}

}
