package bl.userbl;

import util.ResultMessage;
import vo.account.AccountVO;
import blservice.usermesblservice.UserMesblservice;
 /** 
 * 
 * @author czq 
 * @version 2015年11月15日 上午9:27:39 
 */
public class UserController implements UserMesblservice{

	public ResultMessage login(AccountVO vo) {
		// TODO Auto-generated method stub
		return null;
	}

	public ResultMessage modify(AccountVO vo) {
		// TODO Auto-generated method stub
		return null;
	}



	public AccountVO getMes(String ID) {
		// TODO Auto-generated method stub
		return null;
	}

}
