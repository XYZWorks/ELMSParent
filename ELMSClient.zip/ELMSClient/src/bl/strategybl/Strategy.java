package bl.strategybl;

import java.util.ArrayList;

import blservice.strategyblservice.StrategyblService;
import ds.strategydataservice.StrategyDataService;
import util.ResultMessage;
import util.StaffType;
import vo.strategy.ConstVO;
import vo.strategy.SalaryWayVO;

/** 
 * @author ymc 
 * @version 创建时间：2015年10月27日 下午7:50:58 
 *
 */
public class Strategy {
	StrategyDataService strategyData;
	public ConstVO getConst() {
		// TODO Auto-generated method stub
		return null;
	}

	public ResultMessage setConst(ConstVO vo) {
		// TODO Auto-generated method stub
		return null;
	}

	public ArrayList<SalaryWayVO> getsalary() {
		// TODO Auto-generated method stub
		return null;
	}

	public SalaryWayVO getOneSalary(StaffType type) {
		// TODO Auto-generated method stub
		return null;
	}

	public ResultMessage setSalary(SalaryWayVO way) {
		// TODO Auto-generated method stub
		return null;
	}

}
