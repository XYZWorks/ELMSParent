package bl.strategybl;

import java.util.ArrayList;

import util.ResultMessage;
import util.StaffType;
import vo.strategy.ConstVO;
import vo.strategy.SalaryWayVO;
import blservice.strategyblservice.StrategyblService;
 /** 
 * 
 * @author czq 
 * @version 2015年11月15日 上午9:26:46 
 */
public class StrategyController implements StrategyblService{

	public ConstVO getConst() {
		// TODO Auto-generated method stub
		return null;
	}

	public ResultMessage setConst(ConstVO vo) {
		// TODO Auto-generated method stub
		return null;
	}

	public ArrayList<SalaryWayVO> getsalary() {
		// TODO Auto-generated method stub
		return null;
	}

	public SalaryWayVO getOneSalary(StaffType type) {
		// TODO Auto-generated method stub
		return null;
	}

	public ResultMessage setSalary(SalaryWayVO way) {
		// TODO Auto-generated method stub
		return null;
	}

}
