package blservice.financeblservice;
/** 
 * @author ymc 
 * @version 创建时间：2015年11月1日 下午8:31:19 
 *
 */
public interface BankAccountService {

}
