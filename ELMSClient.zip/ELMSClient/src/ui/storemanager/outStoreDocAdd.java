package ui.storemanager;

public class outStoreDocAdd {

}
