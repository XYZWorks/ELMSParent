package ui.storemanager;

public class AlarmValueRecover {

}
