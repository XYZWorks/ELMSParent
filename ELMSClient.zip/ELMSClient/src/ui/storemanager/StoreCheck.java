package ui.storemanager;
/**
 * 库存盘点
 * 
 * @author xingcheng
 *
 */
public class StoreCheck {

}
