package ui.storemanager;

public class AlarmValueSet {

}
