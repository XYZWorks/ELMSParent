package ui.storemanager;

public class InstoreDocAdd {

}
