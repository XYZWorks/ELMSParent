package ui.storemanager;

public class outStoreDocShow {

}
