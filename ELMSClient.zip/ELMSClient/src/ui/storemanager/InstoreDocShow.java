package ui.storemanager;

public class InstoreDocShow {

}
