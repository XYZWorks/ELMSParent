package ui.tools;

import javax.swing.JList;
 /** 
 * 
 * @author czq 
 * @version 2015年11月23日 上午12:12:25 
 */
@SuppressWarnings("serial")
public class MyList extends JList {

}
