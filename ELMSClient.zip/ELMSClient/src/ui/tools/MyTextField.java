package ui.tools;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JTextField;

/**
 * 
 * @author czq
 * @version 2015年11月16日 下午7:37:20
 */
@SuppressWarnings("serial")
public class MyTextField extends JTextField {

	public MyTextField() {
		this.setOpaque(true);
		this.setForeground(Color.BLACK);
		
		
		this.setVisible(true);
		
	}
	
	
}
