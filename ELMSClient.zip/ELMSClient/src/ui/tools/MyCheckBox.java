package ui.tools;

import javax.swing.JCheckBox;
 /** 
 * 
 * @author czq 
 * @version 2015年11月22日 下午11:25:50 
 */
@SuppressWarnings("serial")
public class MyCheckBox extends JCheckBox{
	public MyCheckBox() {
		this.setOpaque(true);
		this.setVisible(true);
	}
}
