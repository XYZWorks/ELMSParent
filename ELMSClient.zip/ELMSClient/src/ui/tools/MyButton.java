package ui.tools;

import java.awt.Graphics;

import javax.swing.JButton;

/**
 * 
 * @author czq
 * @version 2015年11月16日 下午7:35:33
 */
@SuppressWarnings("serial")
public class MyButton extends JButton {
	
	public MyButton() {
		this.setOpaque(true);
		this.setVisible(true);
	}
	
	public MyButton(String text) {
		super.setText(text);
		this.setOpaque(true);
		this.setVisible(true);
	}

}
