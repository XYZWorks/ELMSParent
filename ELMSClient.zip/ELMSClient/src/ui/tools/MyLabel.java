package ui.tools;

import javax.swing.JLabel;
 /** 
 * 
 * @author czq 
 * @version 2015年11月16日 下午7:35:59 
 */
public class MyLabel extends JLabel{

}
