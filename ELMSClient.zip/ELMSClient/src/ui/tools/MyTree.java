package ui.tools;

import javax.swing.JTree;
 /** 
 * 如果要实现菜单中包含子菜单，采用tree
 * @author czq 
 * @version 2015年11月23日 上午12:19:23 
 */
@SuppressWarnings("serial")
public class MyTree extends JTree{

}
