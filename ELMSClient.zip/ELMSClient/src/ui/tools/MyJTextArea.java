package ui.tools;

import java.awt.Graphics;

import javax.swing.JTextArea;

/**
 * 
 * @author czq
 * @version 2015年11月16日 下午7:37:45
 */
public class MyJTextArea extends JTextArea {

	public void paintCompoment(Graphics g) {

	}
}
