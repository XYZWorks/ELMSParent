package ui.mainui;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * 主界面
 * @author czq
 * 10-19
 */
public class mainFrame extends JFrame{
	public mainFrame() {
		
		JFrame frame = new JFrame();
		frame.setSize(1080, 720);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//EXIT_ON_CLOSE（在 JFrame 中定义）：使用 System exit 方法退出应用程序。仅在应用程序中使用。
		frame.setLayout(null);//不使用布局函数
		frame.setLocationRelativeTo(null);//使窗口显示在屏幕正中央
		//??? 
		frame.setResizable(false);	
		
		
		

		}
		
		
		
		
		
	
	
	
}
