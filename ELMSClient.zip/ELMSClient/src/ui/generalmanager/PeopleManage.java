package ui.generalmanager;
/**
 * 人员管理
 * @author xingcheng
 *
 */
public class PeopleManage {

}
