package ui.generalmanager;
/**
 * 机构管理
 * @author xingcheng
 *
 */
public class InstManage {

}
