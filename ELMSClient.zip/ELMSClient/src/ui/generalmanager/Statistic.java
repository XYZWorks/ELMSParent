package ui.generalmanager;
/**
 * 统计分析
 * @author xingcheng
 *
 */
public class Statistic {

}
