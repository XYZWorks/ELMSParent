package ui.generalmanager;
/**
 * 指定薪水策略
 * @author xingcheng
 *
 */
public class SalaryStrategySet {

}
