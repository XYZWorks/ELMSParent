package ui.generalmanager;
/**
 * 指定常量界面
 * @author xingcheng
 *
 */
public class ConstSet {

}
