package ui.generalmanager;
/**
 * 审批单据
 * @author xingcheng
 *
 */
public class GMApproval {

}
