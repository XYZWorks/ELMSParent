package ui.financeman;
/**
 * 付款单的显示
 * 
 * @author xingcheng
 *
 */
public class PayDocShow {

}
