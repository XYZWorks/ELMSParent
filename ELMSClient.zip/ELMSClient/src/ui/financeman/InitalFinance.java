package ui.financeman;
/**
 * 期初建账
 * @author xingcheng
 *
 */
public class InitalFinance {

}
