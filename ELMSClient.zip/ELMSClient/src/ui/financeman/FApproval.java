package ui.financeman;
/**
 * 财务人员的交易审核界面
 * @author xingcheng
 *
 */
public class FApproval {

}
