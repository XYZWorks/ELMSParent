package ui.financeman;
/**
 * 增加成本收益表界面
 * @author xingcheng
 *
 */
public class DepositeProfitAdd {

}
