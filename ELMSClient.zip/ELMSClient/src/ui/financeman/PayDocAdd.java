package ui.financeman;
/**
 * 新建付款单
 * @author xingcheng
 *
 */
public class PayDocAdd {

}
