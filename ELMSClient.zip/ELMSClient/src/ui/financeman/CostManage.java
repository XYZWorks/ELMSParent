package ui.financeman;
/**
 * 成本管理
 * 
 * @author xingcheng
 *
 */
public class CostManage {

}
