package ui.saleman;

public class ArriveYYDocAdd {

}
