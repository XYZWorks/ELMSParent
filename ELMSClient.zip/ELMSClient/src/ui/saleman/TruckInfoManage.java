package ui.saleman;

public class TruckInfoManage {

}
