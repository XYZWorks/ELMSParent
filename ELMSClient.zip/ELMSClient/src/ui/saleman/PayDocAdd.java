package ui.saleman;

public class PayDocAdd {

}
