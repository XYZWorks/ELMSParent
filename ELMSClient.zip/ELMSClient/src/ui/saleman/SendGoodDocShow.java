package ui.saleman;

public class SendGoodDocShow {

}
