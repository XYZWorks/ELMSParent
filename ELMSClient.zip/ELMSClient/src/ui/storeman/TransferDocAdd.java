package ui.storeman;

public class TransferDocAdd {

}
