package ui.storeman;
/**
 * 库存查看
 * storeman+storemanager均可操作
 * @author xingcheng
 *
 */
public class StoreShow {

}
