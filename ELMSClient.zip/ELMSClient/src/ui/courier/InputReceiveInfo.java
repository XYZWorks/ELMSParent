package ui.courier;

public class InputReceiveInfo {

}
