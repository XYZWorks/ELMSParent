package vo.finance;

/**
 * 运费信息
 * @author ymc
 *
 */
public class FreightVO extends CostVO {
	public FreightVO() {
		// TODO Auto-generated constructor stub
	}
	public FreightVO(int money, String type) {
		super(money, type);
		// TODO Auto-generated constructor stub
	}

}
