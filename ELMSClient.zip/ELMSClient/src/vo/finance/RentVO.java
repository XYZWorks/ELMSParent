package vo.finance;

/**
 * 租金信息
 * @author ymc
 *
 */
public class RentVO extends CostVO {
	public RentVO() {
		// TODO Auto-generated constructor stub
	}
	public RentVO(int money, String type) {
		super(money, type);
		// TODO Auto-generated constructor stub
	}

}
